import re
from zlapi import ZaloAPI, ZaloAPIException
from zlapi.models import *
from zlapi import Message, ThreadType, Mention, MessageStyle, MultiMsgStyle
import time
from datetime import datetime
import threading
import json
def lenhadminvip():
    try:
        with open('admin.json', 'r') as adminvip:
            adminzalo = json.load(adminvip)
            return set(adminzalo.get('idadmin', []))
    except FileNotFoundError:
        return set()
idadmin = lenhadminvip()
class zalo_bot_tmr(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies):
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)
        self.spamming = False
        self.spam_thread = None
        self.spammingvip = False
        self.spam_threadvip = None
    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        print(f"\033[32m{message} \033[39m|\033[31m {author_id}\033[0m\n")
        content = message_object.content if message_object and hasattr(message_object, 'content') else ""
        if not isinstance(message, str):
            print(f"{type(message)}")
            return
        if message.startswith(".-help"):
            self.replyMessage(Message(text='''
Lệnh Bot Gồm:

.-help : Show Tất Cả Các Lệnh
.uid
all : Tag All Ẩn
spam : Spam Thường
stopspam : Stop Spam Thường
spamvip : Spam Vip + All
stopspamvip : Stop Spam Vip
            '''), message_object, thread_id=thread_id, thread_type=thread_type)
        elif message.startswith(".uid"):
            user_id = None
            if message_object.mentions:
                user_id = message_object.mentions[0]['uid']
            elif content[5:].strip().isnumeric():
                user_id = content[5:].strip()
            else:
                user_id = author_id
            user_info = self.fetchUserInfo(user_id)
            infozalo = self.checkinfo(user_id, user_info)
            self.replyMessage(Message(text=infozalo, parse_mode="HTML"), message_object, thread_id=thread_id, thread_type=thread_type)
            return
        elif message.startswith("spamvip"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text=''), message_object, thread_id=thread_id, thread_type=thread_type)
                return
            args = content.split()
            if len(args) >= 3:
                message = "".join(args[1:-1])
                try:
                    delay = float(args[-1])
                    if delay < 0:
                        self.replyMessage(Message(text=''), message_object, thread_id=thread_id, thread_type=thread_type)
                        return
                    self.chayspamvip(message, delay, thread_id, thread_type)
                except ValueError:
                    self.replyMessage(Message(text=''), message_object, thread_id=thread_id, thread_type=thread_type)
            else:
                self.replyMessage(Message(text=''), message_object, thread_id=thread_id, thread_type=thread_type)
        elif message.startswith("stopspamvip"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='.'), message_object, thread_id=thread_id, thread_type=thread_type)
                return
            self.dungspamvip()
            self.replyMessage(Message(text='Đã Stop Spam'), message_object, thread_id=thread_id, thread_type=thread_type)
        elif message.startswith("spam"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text=''), message_object, thread_id=thread_id, thread_type=thread_type)
                return
            args = content.split()
            if len(args) >= 3:
                message = " ".join(args[1:-1])
                try:
                    delay = float(args[-1])
                    if delay < 0:
                        self.replyMessage(Message(text=''), message_object, thread_id=thread_id, thread_type=thread_type)
                        return
                    self.chayspam(message, delay, thread_id, thread_type)
                except ValueError:
                    self.replyMessage(Message(text=''), message_object, thread_id=thread_id, thread_type=thread_type)
            else:
                self.replyMessage(Message(text=''), message_object, thread_id=thread_id, thread_type=thread_type)
        elif message.startswith("stopspam"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='.'), message_object, thread_id=thread_id, thread_type=thread_type)
                return
            self.dungspam()
            self.replyMessage(Message(text='Đã Stop Spam'), message_object, thread_id=thread_id, thread_type=thread_type)
        elif message.startswith("all"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text=''), message_object, thread_id=thread_id, thread_type=thread_type)
                return
            mention = Mention(uid='-1', offset=0, length=0)
            zalo_bot_tmr.send(Message(text="@All", mention=mention), thread_id=thread_id, thread_type=thread_type)
    def chayspamvip(self, message, delay, thread_id, thread_type):
        if self.spammingvip:
            self.dungspamvip()
        self.spammingvip = True
        self.spam_threadvip = threading.Thread(target=self.spamtagallvip, args=(message, delay, thread_id, thread_type))
        self.spam_threadvip.start()
    def dungspamvip(self):
        if self.spammingvip:
            self.spammingvip = False
            if self.spam_threadvip is not None:
                self.spam_threadvip.join()
            self.spam_threadvip = None
    def spamtagallvip(self, message, delay, thread_id, thread_type):
        while self.spammingvip:
            mention = Mention(uid='-1', offset=0, length=0)
            zalo_bot_tmr.send(Message(text=message, mention=mention), thread_id=thread_id, thread_type=thread_type)
            time.sleep(delay)
    def chayspam(self, message, delay, thread_id, thread_type):
        if self.spamming:
            self.dungspam()
        self.spamming = True
        self.spam_thread = threading.Thread(target=self.spamtagall, args=(message, delay, thread_id, thread_type))
        self.spam_thread.start()
    def dungspam(self):
        if self.spamming:
            self.spamming = False
            if self.spam_thread is not None:
                self.spam_thread.join()
            self.spam_thread = None
    def spamtagall(self, message, delay, thread_id, thread_type):
        while self.spamming:
            zalo_bot_tmr.send(Message(text=message), thread_id=thread_id, thread_type=thread_type)
            time.sleep(delay)
    def checkinfo(self, user_id, user_info):
        if 'changed_profiles' in user_info and user_id in user_info['changed_profiles']:
            profile = user_info['changed_profiles'][user_id]
            infozalo = f'''
<b>Tên: </b> {profile.get('displayName', '')}
<b>ID: </b> {profile.get('userId', '')}
            '''
            return infozalo
        else:
            return "Chịu Dell Thấy Người Dùng Này Á."
#Nhập Imei Lấy Từ Acc Zalo Á
imei = "6e520b66-39e3-442d-a7dd-22af4ef8e17f-b78b4e2d6c0a362c418b145fe44ed73f"
#Nhập Cookie
session_cookies = {"_ga_EMPDQGGXRL":"GS1.1.1724306721.3.0.1724306721.0.0.0","_zlang":"vn","ozi":"2000.SSZzejyD3jSlZ-JbmGaDbdk3xQZ3HXZOTPklzD5CLvHscEMxqqXIbd2Px_RLILZUSPdfzD99LT4q.1","_ga":"GA1.2.1390301050.1724074678","_gid":"GA1.2.1816285144.1724306779","zpsid":"ljzI.416113108.0.eYjROLHl2IM03iGzM6y99I4SUn5bMJWKPruv7LLOmPbdWL6uLU3Gup9l2IK","zpw_sek":"0SfB.416113108.a0.bpwyveVBsfrJgXU5filQdVpfl_QbyVZFwvAEgF-AdUheYkBxm9wYt_20dDlmzkU_-ihjLJluDCKQoaX4GQtQdG","__zi":"3000.SSZzejyD3jSlZ-JbmGaDbdk3xQZ3HXZOTPkkzD5CLfHnckMvr4vHbNZLvRxU1b2LVjVYlZavD0.1","__zi-legacy":"3000.SSZzejyD3jSlZ-JbmGaDbdk3xQZ3HXZOTPkkzD5CLfHnckMvr4vHbNZLvRxU1b2LVjVYlZavD0.1","app.event.zalo.me":"7496084208811295374"}
zalo_bot_tmr = zalo_bot_tmr('api_key', 'secret_key', imei=imei, session_cookies=session_cookies)
zalo_bot_tmr.listen()
